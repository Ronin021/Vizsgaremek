import { request } from "./client.js";

export async function getProducts() {
  return request("/products");
}

export async function getProductById(id) {
  return request(`/products/${id}`);
}

export async function getProductsByCategory(categoryId) {
  return request(`/products?category_id=${categoryId}`);
}
