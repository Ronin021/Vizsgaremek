/**
 * Jelszó hashelése bcryptjs-sel
 * @param password - A kódolandó jelszó
 * @returns A hash-elt jelszó
 */
export declare const hashPassword: (password: string) => string;
/**
 * Jelszó összehasonlítása a hash-elt verzióval
 * @param password - Az eredeti jelszó
 * @param hash - A hash-elt jelszó
 * @returns true ha egyezik, false ha nem
 */
export declare const comparePassword: (password: string, hash: string) => boolean;
