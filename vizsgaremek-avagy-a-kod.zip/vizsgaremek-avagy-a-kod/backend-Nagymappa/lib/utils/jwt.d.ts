interface TokenPayload {
    userId: number;
    email?: string;
    iat?: number;
}
/**
 * JWT token generálása
 * @param userId - A felhasználó ID-ja
 * @param email - A felhasználó email-je (opcionális)
 * @returns Az aláírt token
 */
export declare const generateToken: (userId: number, email?: string) => string;
/**
 * JWT token ellenőrzése és dekódolása
 * @param token - Az ellenőrizendő token
 * @returns A dekódolt payload vagy null ha hibás
 */
export declare const verifyToken: (token: string) => TokenPayload | null;
/**
 * JWT token dekódolása anélkül, hogy ellenőrizné
 * @param token - Az ellenőrizendő token
 * @returns A dekódolt payload vagy null ha hibás
 */
export declare const decodeToken: (token: string) => TokenPayload | null;
export {};
