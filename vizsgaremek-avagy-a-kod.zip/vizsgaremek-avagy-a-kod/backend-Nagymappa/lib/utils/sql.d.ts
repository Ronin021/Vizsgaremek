export declare const buildInsertQuery: (table: string, fields: string[], values: any[]) => string;
export declare const buildUpdateQuery: (table: string, fields: string[], _id: number) => string;
