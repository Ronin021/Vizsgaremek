import { Request, Response } from 'express';
export declare const getAllOrderItems: (_req: Request, res: Response) => Promise<void>;
export declare const getOrderItem: (req: Request, res: Response) => Promise<void>;
export declare const getOrderItems: (req: Request, res: Response) => Promise<void>;
export declare const createOrderItem: (req: Request, res: Response) => Promise<void>;
export declare const updateOrderItem: (req: Request, res: Response) => Promise<void>;
export declare const deleteOrderItem: (req: Request, res: Response) => Promise<void>;
