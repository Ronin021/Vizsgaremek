import { Request, Response } from 'express';
/**
 * Felhasználó regisztrációja
 */
export declare const register: (req: Request, res: Response) => Promise<void>;
/**
 * Felhasználó bejelentkezése
 */
export declare const login: (req: Request, res: Response) => Promise<void>;
/**
 * Jelenlegi felhasználó info lekérése
 */
export declare const getCurrentUser: (req: Request, res: Response) => Promise<void>;
