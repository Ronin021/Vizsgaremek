import { Request, Response } from 'express';
export declare const getAllOrders: (_req: Request, res: Response) => Promise<void>;
export declare const getOrder: (req: Request, res: Response) => Promise<void>;
export declare const getOrdersByUser: (req: Request, res: Response) => Promise<void>;
export declare const createOrder: (req: Request, res: Response) => Promise<void>;
export declare const updateOrder: (req: Request, res: Response) => Promise<void>;
export declare const deleteOrder: (req: Request, res: Response) => Promise<void>;
