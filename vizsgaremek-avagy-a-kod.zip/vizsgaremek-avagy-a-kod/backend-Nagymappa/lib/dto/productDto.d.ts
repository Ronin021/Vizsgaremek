export interface ProductDto {
    name: string;
    category_id: number;
    price: number;
    description: string;
    stock: number;
}
