import { OrderItem } from '../models/OrderItem';
export declare const getAllOrderItems: () => Promise<OrderItem[]>;
export declare const getOrderItemById: (id: number) => Promise<OrderItem | null>;
export declare const getOrderItemsByOrderId: (orderId: number) => Promise<OrderItem[]>;
export declare const createOrderItem: (orderId: number, productId: number, quantity: number) => Promise<number>;
export declare const updateOrderItem: (id: number, orderId: number, productId: number, quantity: number) => Promise<boolean>;
export declare const deleteOrderItem: (id: number) => Promise<boolean>;
