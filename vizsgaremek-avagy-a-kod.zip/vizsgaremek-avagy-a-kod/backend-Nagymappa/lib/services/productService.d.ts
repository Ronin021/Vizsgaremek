import { Product } from '../models/Product';
import { ProductDto } from '../dto/productDto';
export declare const getAllProducts: () => Promise<Product[]>;
export declare const getProductById: (id: number) => Promise<Product | null>;
export declare const createProduct: (product: ProductDto) => Promise<number>;
export declare const updateProduct: (id: number, product: ProductDto) => Promise<boolean>;
export declare const deleteProduct: (id: number) => Promise<boolean>;
