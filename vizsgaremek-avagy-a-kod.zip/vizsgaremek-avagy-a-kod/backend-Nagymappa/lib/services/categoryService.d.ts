import { Category } from '../models/Category';
export declare const getAllCategories: () => Promise<Category[]>;
export declare const getCategoryById: (id: number) => Promise<Category | null>;
export declare const createCategory: (name: string) => Promise<number>;
export declare const updateCategory: (id: number, name: string) => Promise<boolean>;
export declare const deleteCategory: (id: number) => Promise<boolean>;
