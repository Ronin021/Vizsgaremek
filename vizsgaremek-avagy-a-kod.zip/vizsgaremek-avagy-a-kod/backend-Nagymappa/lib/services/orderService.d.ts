import { Order } from '../models/Order';
import { OrderDto } from '../dto/orderDto';
export declare const getAllOrders: () => Promise<Order[]>;
export declare const getOrderById: (id: number) => Promise<Order | null>;
export declare const getOrdersByUserId: (userId: number) => Promise<Order[]>;
export declare const createOrder: (order: OrderDto) => Promise<number>;
export declare const updateOrder: (id: number, order: OrderDto) => Promise<boolean>;
export declare const deleteOrder: (id: number) => Promise<boolean>;
