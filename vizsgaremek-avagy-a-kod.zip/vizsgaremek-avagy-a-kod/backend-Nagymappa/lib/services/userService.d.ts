import { User } from '../models/User';
import { UserDto } from '../dto/userDto';
export declare const getAllUsers: () => Promise<User[]>;
export declare const getUserById: (id: number) => Promise<User | null>;
export declare const getUserByEmail: (email: string) => Promise<User | null>;
export declare const createUser: (user: UserDto) => Promise<number>;
export declare const updateUser: (id: number, user: UserDto) => Promise<boolean>;
export declare const deleteUser: (id: number) => Promise<boolean>;
